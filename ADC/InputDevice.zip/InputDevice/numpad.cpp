#include "numpad.h"
#include "ui_numpad.h"

Numpad::Numpad(QWidget *parent) :
    QWidget(parent, Qt::Tool | Qt::WindowStaysOnTopHint),
    ui(new Ui::Numpad)
{
    ui->setupUi(this);

    connect(qApp, SIGNAL(focusChanged(QWidget*,QWidget*)),
            this, SLOT(saveFocusWidget(QWidget*,QWidget*)));

    this->setFixedSize(this->width(),this->height());
    keyList=ui->keyholder->children();
    initKeys();
}

Numpad::~Numpad()
{
    delete ui;
}

void Numpad::activate(QVariant initValue,float min,float max,bool Float)
{
    ui->btn_period->setEnabled(Float);
    ui->edValue->setText(initValue.toString());
    min_=min;
    max_=max;
    if(min_==max_)
    {
        ui->lbl_max_value->setText("---");
        ui->lbl_min_value->setText("---");
    }
    else
    {
        ui->lbl_max_value->setText(QString::number(max_));
        ui->lbl_min_value->setText(QString::number(min_));
    }
    show();
}

void Numpad::initKeys()
{
    QPushButton *button;

    for(int i=0;i<keyList.count();i++)
    {
        button=qobject_cast<QPushButton *>(keyList.at(i));
        if(button != 0)
        {
            if((button->property("btnMode").toInt() == 0) || (button->property("btnMode").toInt() == 1))
            {
                connect(button,SIGNAL(clicked()),this,SLOT(buttonClicked()));
            }
            else if(button->property("btnMode").toInt() == 2)
            {
                if(button->property("btnNormal")=="ok")
                {
                    connect(button,SIGNAL(clicked()),this,SLOT(enterClicked()));
                }
                else if(button->property("btnNormal")=="escape")
                {
                    connect(button,SIGNAL(clicked()),this,SLOT(escapeClicked()));
                }
                else if(button->property("btnNormal")=="clear")
                {
                    connect(button,SIGNAL(clicked()),this,SLOT(clearClicked()));
                }
                else if(button->property("btnNormal")=="backspace")
                {
                    connect(button,SIGNAL(clicked()),this,SLOT(backspaceClicked()));
                }
                else if(button->property("btnNormal")=="period")
                {
                    connect(button,SIGNAL(clicked()),this,SLOT(periodClicked()));
                }
                else if(button->property("btnNormal")=="pm")
                {
                    connect(button,SIGNAL(clicked()),this,SLOT(pmClicked()));
                }
            }
        }

    }
}

void Numpad::enterClicked()
{
    QString tmp1,tmp2;
    tmp1=ui->edValue->text().right(1);
    tmp2=ui->btn_period->text();
    if(tmp1 == tmp2)
    {
        ui->edValue->setText(ui->edValue->text().left(ui->edValue->text().length()-1));
    }
    popData();
}

void Numpad::escapeClicked()
{
    close();
}

void Numpad::clearClicked()
{
    ui->edValue->setText("0");
}

void Numpad::periodClicked()
{
    if (!ui->edValue->text().contains(ui->btn_period->text()))
    {
        ui->edValue->setText(ui->edValue->text() + ui->btn_period->text());
    }
}

void Numpad::pmClicked()
{
    QString text = ui->edValue->text();
    if (text.left(1) == "-")
    {
        text = text.right(text.length()-1);
    }
    else
    {
        text = "-"+text;
    }
    if (checkValue(text))
    {
        ui->edValue->setText(text);
    }

}

void Numpad::backspaceClicked()
{
    QString text = ui->edValue->text();
    text.chop(1);
    if (text.isEmpty()) {
        text = "0";
    }
    ui->edValue->setText(text);
}

void Numpad::popData()
{

    emit dataSet(&QVariant(ui->edValue->text()));
    close();
}

void Numpad::buttonClicked()
{
    QPushButton *tmp;
    QString text;
    tmp = qobject_cast<QPushButton *>(sender());
    if (ui->edValue->text() == "0")
    {
        if  (tmp->text() != "0")
        {
            text=tmp->text();
        }
    }
    else
    {
        text=ui->edValue->text()+tmp->text();
    }
    if (checkValue(text))
    {
        ui->edValue->setText(text);
    }
}

bool Numpad::checkValue(QString value)
{
    return ((value.toFloat() >= min_) && (value.toFloat() <= max_)) ||(max_==min_);
}

bool Numpad::event(QEvent *e)
{
    switch (e->type()) {
    case QEvent::WindowActivate:
        if (lastFocusedWidget)
            lastFocusedWidget->activateWindow();
        break;
    default:
        break;
    }

    return QWidget::event(e);
}

void Numpad::saveFocusWidget(QWidget * /*oldFocus*/, QWidget *newFocus)
{
    if (newFocus != 0 && !this->isAncestorOf(newFocus)) {
        lastFocusedWidget = newFocus;
    }
}

