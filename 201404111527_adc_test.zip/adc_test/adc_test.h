//*****************************************************************************
//
// File Name:  adc_test.h
//
//          Rev        Date         Name        Reason
//          -------    --------     --------    -------------------------------
//          1.00       11-04-14			S.Venroy		Created  
//
//*****************************************************************************
#ifndef ADC_TEST_H_
#define ADC_TEST_H_


#define false	0
#define true	!false

typedef unsigned char BYTE;
typedef unsigned int	WORD;
typedef unsigned long	DWORD;
typedef unsigned char BOOL;

//typedef unsigned char bool;


#define FALSE	0
#define TRUE	!FALSE


#endif /* ADC_TEST_H_ */
